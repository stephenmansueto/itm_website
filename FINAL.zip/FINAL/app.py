from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import scoped_session, sessionmaker
from datetime import datetime
from flask_migrate import Migrate


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///matteoreservation.db'
db = SQLAlchemy(app)
migrate = Migrate(app, db)


class YourTable(db.Model):
    __tablename__ = 'matteores'
    index = db.Column(db.Integer, primary_key=True)
    table_class = db.Column(db.String)
    id = db.Column(db.Integer, db.CheckConstraint('LENGTH(CAST(id AS TEXT)) = 6'), nullable=False)
    surname = db.Column(db.String, nullable=False)
    dateofres = db.Column(db.Date, nullable=False)
    time_start = db.Column(db.Time, nullable=False)
    time_end = db.Column(db.Time, nullable=False)

    def __repr__(self):
        return '<Task %r>' % self.id

# Create the table inside the application context
with app.app_context():
    db.create_all()

@app.route('/submit', methods=['POST', 'GET'])
def submit():
    # Retrieve form data
    table_class = str(request.form['table_class_input'])
    id = request.form['id']
    surname = request.form['surname']
    dateofres_str = request.form['dateofres']  # Get date string from form
    time_start_str = request.form['time_start']  # Get time string from form
    time_end_str = request.form['time_end']  # Get time string from form

    # Convert date and time strings to Python date and time objects
    dateofres = datetime.strptime(dateofres_str, '%Y-%m-%d').date()
    time_start = datetime.strptime(time_start_str, '%H:%M').time()
    time_end = datetime.strptime(time_end_str, '%H:%M').time()

    # Create an application context to use the db_session
    with app.app_context():
        # Create the scoped_session inside the application context
        db_session = scoped_session(sessionmaker(bind=db.engine))

        # Insert data into the table using SQLAlchemy
        new_record = YourTable(
            table_class=table_class,
            id=id,
            surname=surname,
            dateofres=dateofres,
            time_start=time_start,
            time_end=time_end
        )

        # Use the scoped_session to add and commit the record
        db_session.add(new_record)
        db_session.commit()

        # Close the session to release resources
        db_session.close()

    # Provide feedback to the user
    return render_template('reserve-submitted.html')


@app.route('/', methods =['GET', 'POST'])
def index():
    return render_template('welcome-page.html')

@app.route('/welcomepage', methods =['GET', 'POST'])
def welcomepage():
    return render_template('welcome-page.html')

@app.route('/about', methods =['GET', 'POST'])
def about():
    return render_template('about.html')

@app.route('/birdseye', methods =['GET', 'POST'])
def birdseye():
    return render_template('birds-eye.html')

@app.route('/templates/cancel-reservation.html', methods =['GET', 'POST'])
def cancel_reservation():
    return render_template('cancel-reservation.html')

@app.route('/templates/my-reservations.html', methods = ['POST', 'GET'])
def my_reservations():
    username = request.args.get('username')
    tasks = YourTable.query.order_by(YourTable.dateofres).all()
    return render_template('my-reservations.html', tasks = tasks)

@app.route('/delete/<int:index>' )
def delete(index):
    task_to_delete = YourTable.query.get_or_404(index)

    try:
        db.session.delete(task_to_delete)
        db.session.commit()
        return render_template('welcome-page.html')
    except:
        return "there was an issue deleting your reservation"

@app.route('/templates/input.html', methods =['GET', 'POST'])
def input():
    return render_template('input.html')

@app.route('/templates/room-c.html', methods =['GET', 'POST'])
def room_c():
    return render_template('room-c.html')

@app.route('/templates/room-d.html', methods =['GET', 'POST'])
def room_d():
    return render_template('room-d.html')

@app.route('/templates/reserve-submitted.html')
def success():
    return render_template('reserve-submitted.html')

if __name__ == '__main__':
    app.run(debug = True)