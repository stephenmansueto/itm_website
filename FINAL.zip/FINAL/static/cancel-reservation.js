function togglePopup(){
  document.getElementById("popup-1").classList.toggle("active");
}
function login(){
  document.getElementById("popup-2").classList.toggle("active");
}